
# Welcome to the Cinemo trial day!
Below is a how-to guide to get the trial day set up as well as the 2 tasks that you need to complete for today.

#### _*Notes*_:

* Task 1 is backend automation of a web api.
* Task 2 is frontend automation of typical usecases on a web product.
* Carefully look at each of the responses of the API.
* You may not have enough time to do all of it. If that's the case, make sure you have at least some examples of both the API testing as well as the UI automation for both positive and negative test cases
* Feel free to use the internet for research but do not copy code or use any code generation tools or _"phone-a-friend"_. It should be your work. 
* Finally, you'll present your solution to the interview panel at the end where you should take us through the problem, your proposed solution and answer any questions the panel may have.

Good luck!  

## Starting the server
Install the flask package in order to be able to run the webserver
```
pip install flask
```

Open a terminal and run the following command from the project directory 
```
python webserver.py
```
___
This will create a webserver listening on [http://127.0.0.1:5000](http:127.0.0.1:5000)

![Server started](image.png)
___
## Usage
* Once you navigate to the url click sign up and enter in your credentials.
* After sign up you can log in with those credentials.
* Logging in will display a list of registered users.
* The only action you have available is to delete users.

## Task 1 of 2
List of APIs available which should also be tested.
>_/signup_ **(POST)**
>
>|parameter|type|
>|--|--|
>|email|string|
>|password|string|
> * content-type: form-data
> * Reponse: (one of the following)
>___
>> * `User with that email already exists`
>> * `User signed up successfully! <br> <a href= />Log in</a>`
>___
><br/> 
___

>_/login_ **(POST)**
>
>|parameter|type|
>|--|--|
>|email|string|
>|password|string|
> * content-type: form-data
> * Reponse: (one of the following)
>___
>> * `invalid credentials. <br> Back to <a href=/>Login</a>`
>> * `<html>......</html> of the home page after logging in`
>___
><br/>
___

>_/usersapi_ **(GET)**
>* Response:
    JSON object array with registered users
>   ```
>   [
>      {
>         "email": string
>         "id": int
>         "password": string
>      },...
>   ]
>   ```
>   <br/> 
___

>_/delete/**{id}**_ **(POST)**
>* content-type:: NA
>* Reponse:JSON object: (one of the following)
>
>   ```
>   {
>        "success": true
>   }
>   or
>   {
>        "error": "No user with that id",
>        "success": false
>   }
>   ```
>   <br/> 

___

## Task 2
Use Playwright (Typescript is preferable) to automate the use cases below. Ensure that you validate the use case properly.

### User story 1:
`As an unregistered user, I would like to register as a new account.`
> **Acceptance criteria:** 
> * A new user is registered and is stored in the database with the given credentials. 
> * Each new user will receive an _id_ which is unique to that user
><br/> 
<br/> 

### User story 2:

`As a registered user, I want to login to the system using the credentials that I registered with.`
>**Acceptance criteria:**
>*  A registered user is able to login with the registration credentials succesfully. 
> * Once logged in, the user list screen is displayed.
> <br/> 
<br/> 

### User story 3: 
`As a logged in user, I want to be able to delete other users from the system`
>___
>**Acceptance criteria:**
> * From the user list screen, clicking the delete button will delete a user from the list.
> * The list is auto updated and the user is no longer visible
> * The deleted user can no longer log in.
>___
><br/> 

___
