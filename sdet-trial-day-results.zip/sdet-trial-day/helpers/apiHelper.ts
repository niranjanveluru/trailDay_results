import { APIRequestContext } from "playwright";
import { baseApiURL } from "../playwright.config";
import FormData from "form-data";

export class ApiHelper {
    readonly userApiUrl
    readonly request: APIRequestContext

    constructor(request: APIRequestContext){
        this.request = request
        this.userApiUrl = baseApiURL
    }

    async goto(){
        console.log(this.userApiUrl)
        const response =await this.request.get(`${this.userApiUrl}/usersapi`)
        return response
    }

    async getUserInfo(){
        console.log(this.userApiUrl)
        const response =await this.request.get(`${this.userApiUrl}/usersapi`)
        return response
    }

    async signup(userName: string, password: string){
        const form = new FormData()
        form.append('email', userName)
        form.append('password', password)

        form.append('file', Buffer.from('file content'), {
            filename: 'test.txt',
            contentType: 'text/plain'
        })
        const response =await this.request.post(`${this.userApiUrl}/signup`,{
            headers: {
               ...form.getHeaders()
            },
            data: form
        })
        return response
    }

     async signUpUser(userName: string, password: string){
        const response =await this.request.post(`${this.userApiUrl}/signup`,{
            data: {
                email: userName,
                password: password,
            },
            headers: {
                'Content-Type': 'form-data',
            }
        })
        return response
    }

    async deleteUser(id: Number){
        const response =await this.request.post(`${this.userApiUrl}/delete/${id}`)
        return response
    }
}

