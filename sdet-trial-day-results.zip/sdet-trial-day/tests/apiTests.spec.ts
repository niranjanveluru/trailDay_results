import { Page, test, expect } from "@playwright/test";
import { ApiHelper } from "../helpers/apiHelper";
import { URLSearchParams } from "url";

test.describe('API tests', async()=>{

    let apiHelper:ApiHelper

    test.beforeEach('',async({request})=>{
         apiHelper = new ApiHelper(request)
    })

    test('validate usersAPI response and verify existing user email', async()=>{
        const response = await apiHelper.goto()
        const responseBody = await response.json()
        const email = await responseBody.find(user => user.email === 'kumarniranjan97@yahoo.com')
        console.log(email?.email)
        expect(email?.email).toBe('kumarniranjan97@yahoo.com')
    })

     test.skip('sing up new user', async()=>{
        const response = await apiHelper.signup("demo.tester@test.com", "test123")
        const responseBody = await response.text()
        console.log(responseBody)
    })

    test('delete user and validate success response', async()=>{
        const response = await apiHelper.deleteUser(13)
        const responseBody = await response.json()
        expect(await responseBody.success).toBe(true)
    })

     test('delete unknow user and validate failure response', async()=>{
        const response = await apiHelper.deleteUser(15)
        const responseBody = await response.json()
        expect(await responseBody.success).toBe(false)
        expect(await responseBody.error).toContain('No user with that id')
    })
})
