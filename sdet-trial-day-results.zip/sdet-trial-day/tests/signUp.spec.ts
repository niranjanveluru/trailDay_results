import { test,Page, expect } from "@playwright/test";
import { SignUpPage } from "../pages/signUp.page";
import { ApiHelper } from "../helpers/apiHelper";

test.describe('signup tests', async()=>{

    let apiHelper:ApiHelper
    let signUpPage: SignUpPage

    test.beforeEach('',async({request, page})=>{
         apiHelper = new ApiHelper(request)
         signUpPage = new SignUpPage(page)
    })

    test('sign up user', async({page}) => {
        await signUpPage.goTo()
        await signUpPage.signUpLink.click()
        await signUpPage.singUpUser("tester17.user17@test.com","tester17") // signup method to take input and create user
        await expect(signUpPage.page.getByText('User signed up successfully!')).toBeVisible()

        // fetch newly created user id
        const response = await apiHelper.getUserInfo()
        const responseBody = await response.json()
        const user = await responseBody.find(user => user.email === 'tester17.user17@test.com')
    
        // dispaly user id
        if(user){
            console.log(`user id is : ${user.id}`)
        }
    })

     test('sign up existing user', async({page}) => {
        await signUpPage.goTo()
        await signUpPage.signUpLink.click()
        await signUpPage.singUpUser("tester16.user16@test.com","tester16") // signup method to take input and create user
        await expect(signUpPage.page.getByText('User with that email already exists.')).toBeVisible()

    })
})