import { Locator, Page } from "playwright";

export class SignUpPage {
    readonly page:Page
    readonly signUpLink: Locator
    readonly emailInput: Locator
    readonly passwordInput: Locator
    readonly singUpButton: Locator

    constructor(page:Page){
        this.page=page
        this.signUpLink =page.locator('#signupLink')
        this.emailInput = page.locator('#signupModal #email')
        this.passwordInput = page.locator('#signupModal #password')
        this.singUpButton = page.getByRole('button', { name: 'Sign up' })
    }

    async goTo(){
        await this.page.goto('/')
    }

    async singUpUser(username: string, password: string){
        await this.emailInput.fill(username)
        await this.passwordInput.fill(password)
        await this.singUpButton.click()
      
    }
}